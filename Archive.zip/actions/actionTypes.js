import { createTypes } from 'reduxsauce';

export default createTypes(`
SET_NAVIGATOR
SET_SPINNER_VISIBLE
SET_NAV
SET_DATA
`);
