const images = {
	bgSplash: require('@assets/logo.jpg')
};

export default images;
