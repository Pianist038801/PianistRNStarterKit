import React, { Component } from 'react';
import { Text, TextInput, View, Platform, Image, Alert, Linking } from 'react-native';
//import { connect } from 'react-redux';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import I18n from 'react-native-i18n';
import Types from '@actions/actionTypes';
import OverlaySpinner from '@components/OverlaySpinner';
//import CommonWidgets from '@components/CommonWidgets';

// import { Styles, Images, Colors, Fonts, Metrics } from '@theme/';
// import Utils from '@src/utils';
// import styles from './styles';
class Login extends Component {
	constructor(props) {
		super(props);

		this.state = {
			email: '',
			password: ''
		};
	}

	render() {
		return <View />;
	}
}

export default Login;
