import React, { Component } from 'react';
import { Provider } from 'react-redux';
import { Text } from 'react-native';
import Splash from '@containers/Splash';
import Login from '@containers/Authentication/Login';
class Root extends Component {
	render() {
		return <Login />;
	}
}

export default Root;
